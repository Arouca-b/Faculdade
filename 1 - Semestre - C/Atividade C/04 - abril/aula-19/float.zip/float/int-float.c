#include <stdio.h>

int main(void) {
    float f;
    int i;
    printf("Digite um número real: ");
    scanf("%f", &f);
    i = (int) f;
   	printf("\nParte Inteira : %d",i);
    f = f - i;
   	printf("\nParte Decimal : %.2f\n", f);
}